﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Anow.PingPong.Api.Controllers
{
    [Produces("application/json")]
    [Route("Games")]
    public class GamesController : Controller
    {

        [HttpGet]
        public object Get(int id, String pl)
        {
            if (id > 0)
                return filterById(id);
            else if (pl != null)
                return filterByPlayer(pl);
            else if (Program.games.Count > 0)
            {
                String all = "";
                for (int i = 0; i < Program.games.Count; i++)
                    all += Program.games[i].Print();

                return all;

            }
            else
                return new { Empty = "no games recorded yet."};
        }


        private object filterById(int id)
        {
            if (Program.games.Count > 0)
            {
                String all = "";
                for (int i = 0; i < Program.games.Count; i++)
                    if (Program.games[i].getID() == id)
                        all += Program.games[i].Print();

                if (all.Length > 1)
                    return all;
                else
                    return new { Empty = "this person has played no games."};

            }
            else
                return new { Empty = "no games recorded yet." };
        }


        private object filterByPlayer(String pl)
        {
            if (Program.games.Count > 0)
            {
                String all = "";
                for (int i = 0; i < Program.games.Count; i++)
                    if(Program.games[i].hasPlayer(pl))
                        all += Program.games[i].Print();

                if(all.Length > 1)
                    return all;
                else
                    return new { Empty = "this person has played no games."};
            }
            else
                return new { Empty = "no games recorded yet." };
        }
        [HttpPut]
        public object Put()
        {
             return new { Method = "not usable yet."};
        }

        [HttpPost]
        public object Post(String p1,String p2, int sc1, int sc2)
        {
            if ((sc1 > 20 || sc2 > 20) && (Math.Abs(sc1 - sc2) > 1))
            {

                Program.games.Add(new GameData(GenID(),p1, p2, sc1, sc2));
                return Get(0, null);
            }
            else return new { Error = "Invalid data" };
        }

        [HttpDelete]
        public object Del(int id)
        {
            int temp = Program.games.Count;
            for (int i = 0; i < temp; i++)
                if (Program.games[i].getID().Equals(id))
                {
                    Program.games.RemoveAt(i);
                    i = temp;
                }
            return Get(0,null);
        }

        private int GenID()
        {
            if (Program.games.Count == 0)
                return 1;
            else
                return Program.games[Program.games.Count - 1].getID()+1;
        }

    }
}